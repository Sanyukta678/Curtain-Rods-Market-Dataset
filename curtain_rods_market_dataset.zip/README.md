# Curtain Rods Market Dataset

This repository provides a structured dataset derived from publicly available market insights on the global **Curtain Rods Market**.

## Contents
- `curtain_rods_market.csv` — Cleaned, tabular dataset with key market indicators.
- `metadata.txt` — Field descriptions and notes.
- This `README.md`

## Columns in Dataset
- **Year**  
- **Market_Size_USD_Million**  
- **Growth_Rate_%**  
- **Region**  
- **Segment**  

## Disclaimer
This dataset is a simplified, illustrative representation created for analytical and educational use. It is *not* an official dataset from NextMSC.

## How to Use
```bash
unzip curtain_rods_market_dataset.zip
cd curtain_rods_market_dataset
```

You can load the CSV in Python, R, Excel, or any analytics tool.

## Contribution
Feel free to fork and extend this dataset.
